const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

// Schedule this function in GCP Cloud Scheduler to run daily
exports.sendDailyReminders = functions.pubsub.schedule('every 24 hours').onRun(async (context) => {
  const today = new Date();
  // normalize to YYYY-MM-DD (UTC)
  const yyyy = today.getUTCFullYear();
  const mm = String(today.getUTCMonth()+1).padStart(2,'0');
  const dd = String(today.getUTCDate()).padStart(2,'0');
  const todayStr = `${yyyy}-${mm}-${dd}`;

  const start = new Date(Date.UTC(yyyy, today.getUTCMonth(), today.getUTCDate(), 0,0,0));
  const end = new Date(Date.UTC(yyyy, today.getUTCMonth(), today.getUTCDate(), 23,59,59));

  const q = db.collection('donors')
    .where('nextDonation', '>=', admin.firestore.Timestamp.fromDate(start))
    .where('nextDonation', '<=', admin.firestore.Timestamp.fromDate(end));

  const snap = await q.get();
  const messages = [];
  snap.forEach(doc => {
    const data = doc.data();
    if (data.fcmToken) {
      messages.push({
        token: data.fcmToken,
        notification: {
          title: 'Time to donate blood',
          body: `Dear ${data.name}, today is a good day to donate blood again.`
        }
      });
    }
    // mark reminderSent to avoid duplicates
    doc.ref.update({ lastReminderSent: admin.firestore.Timestamp.now() }).catch(()=>{});
  });

  if (messages.length>0) {
    const batch = [];
    // send in chunks
    while(messages.length) {
      const chunk = messages.splice(0,100);
      batch.push(admin.messaging().sendAll(chunk));
    }
    await Promise.all(batch);
  }
  return null;
});
