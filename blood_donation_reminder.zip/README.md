# Blood Donation Reminder - Flutter (Professional) - Minimal Build

This is a minimal, buildable scaffold of the Blood Donation Reminder app.
It contains core Flutter files, Firebase initialization hooks, Firestore service,
notification handling, and a sample Cloud Function to send daily reminders.

## How to use
1. Download this ZIP and open in your machine.
2. Add Firebase config files:
   - Android: android/app/google-services.json
   - iOS: ios/Runner/GoogleService-Info.plist
3. Run:
   ```
   flutter pub get
   flutter run
   ```
4. For scheduled reminders, deploy the Cloud Function under `functions/`.

