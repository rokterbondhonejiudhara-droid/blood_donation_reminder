import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/firestore_service.dart';
import '../models/donor.dart';

class DonorForm extends StatefulWidget {
  final Donor? editDonor;
  DonorForm({this.editDonor});
  @override
  _DonorFormState createState() => _DonorFormState();
}

class _DonorFormState extends State<DonorForm> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  String _blood = 'A+';
  DateTime? _lastDate;

  @override
  void initState() {
    super.initState();
    if (widget.editDonor != null) {
      _name.text = widget.editDonor!.name;
      _phone.text = widget.editDonor!.phone;
      _blood = widget.editDonor!.bloodGroup;
      _lastDate = widget.editDonor!.lastDonation.toDate();
    }
  }

  @override
  Widget build(BuildContext context) {
    final fs = Provider.of<FirestoreService>(context, listen: false);
    return Scaffold(
      appBar: AppBar(title: Text(widget.editDonor==null ? 'Add Donor' : 'Edit Donor')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: _name, decoration: InputDecoration(labelText: 'Name'), validator: (v)=> v==null||v.isEmpty? 'Enter name':null),
              TextFormField(controller: _phone, decoration: InputDecoration(labelText: 'Phone'), validator: (v)=> v==null||v.isEmpty? 'Enter phone':null),
              DropdownButtonFormField<String>(
                value: _blood,
                items: ['A+','A-','B+','B-','O+','O-','AB+','AB-'].map((b)=>DropdownMenuItem(value:b,child:Text(b))).toList(),
                onChanged: (v)=> setState(()=> _blood = v!),
                decoration: InputDecoration(labelText: 'Blood Group'),
              ),
              SizedBox(height:10),
              Row(
                children: [
                  Text(_lastDate==null ? 'Select Last Donation' : DateFormat('dd-MM-yyyy').format(_lastDate!)),
                  Spacer(),
                  ElevatedButton(onPressed: () async {
                    final picked = await showDatePicker(context: context, initialDate: _lastDate ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100));
                    if (picked != null) setState(()=> _lastDate = picked);
                  }, child: Text('Pick Date'))
                ],
              ),
              SizedBox(height:20),
              ElevatedButton(onPressed: () async {
                if (!_formKey.currentState!.validate()) return;
                if (_lastDate==null) { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pick last donation date'))); return; }
                if (widget.editDonor==null) {
                  await fs.addDonor(_name.text.trim(), _phone.text.trim(), _blood, _lastDate!);
                } else {
                  await fs.updateDonorNext(widget.editDonor!.id, _lastDate!);
                }
                Navigator.of(context).pop();
              }, child: Text('Save'))
            ],
          ),
        ),
      ),
    );
  }
}
