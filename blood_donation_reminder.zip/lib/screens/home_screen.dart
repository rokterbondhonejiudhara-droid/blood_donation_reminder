import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firestore_service.dart';
import '../models/donor.dart';
import 'donor_form.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final fs = Provider.of<FirestoreService>(context, listen: false);
    return Scaffold(
      appBar: AppBar(title: Text('Donors')),
      body: StreamBuilder<List<Donor>>(
        stream: fs.streamDonors(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error'));
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final donors = snapshot.data!;
          if (donors.isEmpty) return Center(child: Text('No donors yet'));
          return ListView.builder(
            itemCount: donors.length,
            itemBuilder: (ctx, i) {
              final d = donors[i];
              final next = DateFormat('dd-MM-yyyy').format(d.nextDonation.toDate());
              return ListTile(
                title: Text(d.name + ' (' + d.bloodGroup + ')'),
                subtitle: Text('Next: ' + next),
                trailing: IconButton(
                  icon: Icon(Icons.edit),
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) => DonorForm(editDonor: d)));
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => DonorForm())),
      ),
    );
  }
}
