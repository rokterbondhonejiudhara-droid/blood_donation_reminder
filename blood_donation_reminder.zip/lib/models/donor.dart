import 'package:cloud_firestore/cloud_firestore.dart';

class Donor {
  String id;
  String name;
  String phone;
  String bloodGroup;
  Timestamp lastDonation;
  Timestamp nextDonation;
  String? fcmToken;

  Donor({
    required this.id,
    required this.name,
    required this.phone,
    required this.bloodGroup,
    required this.lastDonation,
    required this.nextDonation,
    this.fcmToken,
  });

  Map<String, dynamic> toMap() => {
        'name': name,
        'phone': phone,
        'bloodGroup': bloodGroup,
        'lastDonation': lastDonation,
        'nextDonation': nextDonation,
        'fcmToken': fcmToken,
      };

  factory Donor.fromDoc(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return Donor(
      id: doc.id,
      name: d['name'] ?? '',
      phone: d['phone'] ?? '',
      bloodGroup: d['bloodGroup'] ?? '',
      lastDonation: d['lastDonation'] ?? Timestamp.now(),
      nextDonation: d['nextDonation'] ?? Timestamp.now(),
      fcmToken: d['fcmToken'],
    );
  }
}
