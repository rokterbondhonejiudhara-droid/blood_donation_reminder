import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/donor.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final CollectionReference donorsRef = FirebaseFirestore.instance.collection('donors');

  Future<void> addDonor(String name, String phone, String bloodGroup, DateTime lastDonation) async {
    DateTime next = lastDonation.add(Duration(days: 90));
    await donorsRef.add({
      'name': name,
      'phone': phone,
      'bloodGroup': bloodGroup,
      'lastDonation': Timestamp.fromDate(lastDonation),
      'nextDonation': Timestamp.fromDate(next),
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<List<Donor>> streamDonors() {
    return donorsRef.orderBy('nextDonation').snapshots().map((snap) =>
        snap.docs.map((d) => Donor.fromDoc(d)).toList());
  }

  Future<void> updateDonorNext(String id, DateTime lastDonation) async {
    DateTime next = lastDonation.add(Duration(days: 90));
    await donorsRef.doc(id).update({
      'lastDonation': Timestamp.fromDate(lastDonation),
      'nextDonation': Timestamp.fromDate(next),
    });
  }
}
