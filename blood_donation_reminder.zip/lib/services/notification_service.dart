import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class NotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _local = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    // Request permission (iOS)
    await _fcm.requestPermission();
    // Initialize local notifications
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _local.initialize(settings);
    // Get token and save if needed
    String? token = await _fcm.getToken();
    if (token != null) {
      // In a real app, save token to users collection or donor record when available
      // Example (requires authentication & mapping): FirebaseFirestore.instance.collection('users').doc(uid).update({'fcmToken': token});
      print('FCM Token: $token');
    }
    FirebaseMessaging.onMessage.listen((message) {
      _showLocal(message.notification?.title ?? 'Reminder', message.notification?.body ?? '');
    });
  }

  Future<void> _showLocal(String title, String body) async {
    const androidDetails = AndroidNotificationDetails('reminder_channel', 'Reminders',
        importance: Importance.max, priority: Priority.high);
    const details = NotificationDetails(android: androidDetails);
    await _local.show(0, title, body, details);
  }
}
